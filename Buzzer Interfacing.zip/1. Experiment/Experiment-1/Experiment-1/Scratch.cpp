#include<stdio.h>
#include<iostream>
#include<string>
#include<string.h>
#include<stdlib.h>
using namespace std;
int main(){
	
}




