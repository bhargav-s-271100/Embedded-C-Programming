#include<stdio.h>
#include<iostream>
#include<string>
#include<string.h>
#include<stdlib.h>
using namespace std;


int main()
{
	int num=255,n=0,m=1;
	char str[20],temp[20];
	while(num!=0)
	{
		n+=(num%2)*m;
		m*=10;
		num/=2;
	}
	cout<<n<<" ";
	sprintf(str,"%08d",n);
	cout<<str;
}
