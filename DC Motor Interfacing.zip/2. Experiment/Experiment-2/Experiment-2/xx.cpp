#define    ADC_Contrl_Reg_A    ADCSRA
#define     ADC_Contrl_Reg_B    ADCSRB
#define     ADC_Mux_Reg         ADMUX
#define     ADSC_bit            ADSC
#define     ADIF_bit            ADIF
#define     MUX5_bit            MUX5
#define     MUX4_bit            MUX4
#define     MUX3_bit            MUX3
#define     MUX2_bit            MUX2
#define     MUX1_bit            MUX1
#define     MUX0_bit            MUX0
void select_adc_channel(unsigned char channel){
 if(channel>7)
{
		ADC_Contrl_Reg_B |=(1<<MUX5_bit);
}
ADC_Mux_reg |= (channel & 0x07);

}
