#define RS_en() lcd_control_port_reg |=(1<<RS_pin)
#define RS_clr() lcd_control_port_reg &= ~(1<<RS_pin)
#define E_en() lcd_control_port_reg |=(1<<EN_pin)
#define E_clr() lcd_control_port_reg &= ~(1<<EN_pin)
#define Data lcd_data_port_reg

void writedata(char t)
{
	RS_en(); /* => RS = 1 */
	Data = t; /* Data transfer */
	E_en(); /* => E = 1 */
	_delay_ms(5);
	E_clr(); /* => E = 0 */
	_delay_ms(5);
}
void writecmd(int z)
{
	RS_clr(); /* => RS = 1 */
	Data = z; /* Data transfer */
	E_en(); /* => E = 1 */
	_delay_ms(5);
	E_clr(); /* => E = 0 */
	_delay_ms(5);
} 

